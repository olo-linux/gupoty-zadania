#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>

using namespace std;

void processCipher(string &napis, const vector<int> &key) {
    for (size_t i = 0; i < key.size(); i++) {
        int target_index = key[i] - 1; 

        if (i < napis.length() && target_index < napis.length()) {
            char temp = napis[i];
            napis[i] = napis[target_index];
            napis[target_index] = temp;
        }
    }
}

int main() {
    ifstream fin("szyfr1.txt");
    if (!fin.is_open()) {
        cerr << "Error opening input file!" << endl;
        return 1;
    }

    string napis_1, napis_2, napis_3, napis_4, napis_5, napis_6;
    string key_line;

    getline(fin, napis_1);
    getline(fin, napis_2);
    getline(fin, napis_3);
    getline(fin, napis_4);
    getline(fin, napis_5);
    getline(fin, napis_6);
    
    getline(fin, key_line);
    fin.close();

    vector<int> key;
    stringstream ss(key_line);
    int num;
    while (ss >> num) {
        key.push_back(num);
    }


    processCipher(napis_1, key);
    processCipher(napis_2, key);
    processCipher(napis_3, key);
    processCipher(napis_4, key); 
    processCipher(napis_5, key); 
    processCipher(napis_6, key); 

    ofstream fout("wyniki_szyfr1.txt");
    if (!fout.is_open()) {
        cerr << "Error creating output file!" << endl;
        return 1;
    }

    fout << napis_1 << "\n";
    fout << napis_2 << "\n";
    fout << napis_3 << "\n";
    fout << napis_4 << "\n";
    fout << napis_5 << "\n";
    fout << napis_6 << "\n";
    
    fout.close();

    return 0;
}

