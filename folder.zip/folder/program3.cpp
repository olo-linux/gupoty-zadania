#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

int main() {
    ifstream fin("szyfr3.txt");
    if (!fin.is_open()) {
        cerr << "Error: Could not open szyfr3.txt!" << endl;
        return 1;
    }

    string napis;
    getline(fin, napis); 
    fin.close();

    vector<int> key = {6, 2, 4, 1, 5, 3};
    int key_size = key.size();

    for (int i = (int)napis.length() - 1; i >= 0; i--) {
        int raw_key_val = key[i % key_size];
         int target_index = raw_key_val - 1;

        if (target_index >= 0 && target_index < (int)napis.length()) {
            char temp = napis[i];
            napis[i] = napis[target_index];
            napis[target_index] = temp;
        }
    }

  
    ofstream fout("wyniki_szyfr3.txt");
    if (fout.is_open()) {
        fout << napis << "\n";
        fout.close();

    } else {
        cerr << "Error creating output file!" << endl;
    }

    return 0;
}

