#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>

using namespace std;

int main() {

    ifstream fin("szyfr2.txt");
    if (!fin.is_open()) {
        cerr << "Error: Could not open szyfr2.txt!" << endl;
        return 1;
    }

    string napis;
    string key_line;
    getline(fin, napis);
    getline(fin, key_line);
    fin.close();

    vector<int> key;
    stringstream ss(key_line);
    int num;
    while (ss >> num) {
        key.push_back(num);
    }

    int key_size = key.size();
    
    for (size_t i = 0; i < napis.length(); i++) {

        int raw_key_val = key[i % key_size];
        int target_index = raw_key_val -1;

        if (target_index >= 0 && target_index < (int)napis.length()) {
            char temp = napis[i];
            napis[i] = napis[target_index];
            napis[target_index] = temp;
        }
    }

    ofstream fout("wyniki_szyfr2.txt");
    if (fout.is_open()) {
        fout << napis << "\n";
        fout.close();
    } else {
        cerr << "Error creating output file!" << endl;
    }

    return 0;
}

